<?php


namespace Site;
use Site\Libs\Storage;
// Почему-то не работают сессии
//if(!isset($_SESSION['login']) || empty($_SESSION['login'])){
//    header("location: /Site/Libs/authorization.php");
//    exit;
//}


//$pdo = new PDO($dsn, $user, $pass, $opt);

//отобразить все элементы из бд
//отображение
//удаление
//пагинация
//безопасность
//интерфесы
//php doc
//документация

spl_autoload_register(function ($class_name) {
    include str_replace('\\','/',__DIR__.'/../'.$class_name . '.php');
});
$store = new Storage('127.0.0.1','site','root','root');
$download=$store->readContacts();

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script type="text/javascript" src="jquery-3.3.1.js"></script>
    <!--Table Sorter-->
    <script type="text/javascript" src="tablesorter.js"></script>
    <script type="text/javascript">
        $(document).ready(function()
            {
                $("#myTable").tablesorter();
            }
        );
    </script>
</head>
<body>

<table border='4' id = 'myTable' class = 'table' width='100%'>
    <thead class="thead-inverse">
    <tr>
        <th><a href="">Login</a></th>
        <th><a href="">Name</a></th>
        <th><a href="">Surname</a></th>
        <th><a href="">Sex</a></th>
        <th><a href="">Birthday</a></th>
        <th><a href="">Admin Rules</a></th>
        <th><a href="">Actions</a></th>
    </tr>
    </thead>
   <?php foreach($download as $key) {?>
    <tr>
        <td><?php echo $key->getLogin();?></td>
        <td><?php echo $key->getFirstname();?></td>
        <td><?php echo $key->getSurname(); ?></td>
        <td><?php echo $key->getSex();?></td>
        <td><?php echo $key->getBirthday();?></td>
        <td><?php echo $key->getAdmin();?></td>
        <td><input type='submit' value='View'>
            <input type='submit' value='Delete'></td>
    </tr>
   <?php }?>
</table>

</body>
</html>

