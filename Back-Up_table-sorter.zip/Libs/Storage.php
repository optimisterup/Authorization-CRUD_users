<?php


namespace Site\Libs;
use PDO;
//if(!defined("IN_ADMIN")) die;
class Storage
{
    private $dsn;
    private $charset='utf8';
    private $pdo;
    private $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    public function __construct($host, $db, $user,$pass)
    {
        $this->dsn = "mysql:host=$host;dbname=$db;charset=$this->charset";
        $this->pdo = new PDO($this->dsn, $user, $pass, $this->opt);
    }

    public function getNewContactInstance(array $data)
    {

        $a=new User();
        $a->setFirstname($data['firstname']);
        return $a;
    }

    public function getEmptyContactInstance()
    {
        $a = new User();
        return $a;
    }

    /**
     * @return array
     */
    public function readContacts(): array
    {
        $stmt=$this->pdo->query("SELECT * FROM users;");

        while ($row = $stmt->fetch()){
            $object =new User();
            $object->setLogin($row['login']);
//            $object->setPassword($row['password']);
            $object->setFirstname($row['firstname']);
            $object->setSurname($row['surname']);
            $object->setSex($row['sex']);
            $object->setBirthday($row['birthday']);
            $object->setAdmin($row['admin']);
            $array[] =$object;
        }
        return $array;
    }

    /**
     * @param array $users
     */
    public function storeContacts(array $users)
    {
        $store=[];
        foreach ($users as $contact){
            $check = $contact->toArray();
            if (strlen(trim($users['login']))==0||
                strlen(trim($users['password']))==0||
                strlen(trim($users['firstname']))==0||
                strlen(trim($users['surname']))==0||
                strlen(trim($users['sex']))==0||
                strlen(trim($users['birthday']))==0||
                strlen(trim($users['admin']))==0)
            {
                continue;
            }
            $store[] = $contact->toArray();
        }
//        UPDATE `site`.`users` SET `name`='Евгения' WHERE `id`='1';

        $this->pdo->query("ALTER TABLE users SET `name`={$users['firstname']};");
    }
}