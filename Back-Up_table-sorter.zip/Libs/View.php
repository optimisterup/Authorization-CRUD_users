<?php
//
//
//namespace Site\Libs;
//
////if(!defined("IN_ADMIN")) die;
//class View
//{
//    public function display(array $users)
//    {
//        echo "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css\">
//              <h1>Список пользователей</h1>";
////        echo"<table border='4' id = 'myTable' class = 'table' width='100%'><tr>
////                <th>Login</th>
////                <th>Name</th>
////                <th>Surname</th>
////                <th>Sex</th>
////                <th>Birthday</th>
////                <th>Admin Rules</th>
////                <th>Actions</th>
////                </tr>";
//        foreach ($users as $key) {
//            echo $key->toHtml();
//        }
//        echo"</table>";
//        echo '<br><br><input type="submit" value="Сохранить"><br>';
//        echo '</form>';
//    }
//}