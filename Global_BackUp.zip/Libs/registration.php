<?php
// Include config file
session_start();
if(!isset($_SESSION['login']) || empty($_SESSION['login'])){
    header("location: /Site/Libs/authorization.php");
    exit;
}
require_once 'config.php';

// Define variables and initialize with empty values
$login = $password = $confirm_password = "";
$login_err = $password_err = $confirm_password_err = "";
$surname =$firstname = $sex = $birthday = $admin = "";
$surname_err =$firstname_err = $sex_err = $birthday_err = $admin_err = "";
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    // Validate login
    if(empty(trim($_POST["login"]))){
        $login_err = "Please enter a login.";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE login = :login";

        if($stmt = $pdo->prepare($sql)){
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(':login', $param_login, PDO::PARAM_STR);

            // Set parameters
            $param_login = trim($_POST["login"]);

            // Attempt to execute the prepared statement
            if($stmt->execute()){
                if($stmt->rowCount() >0){
                    $login_err = "This login is already taken.";
                } else{
                    $login = trim($_POST["login"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        // Close statement
        unset($stmt);
    }

    // Validate password
    if(empty(trim($_POST['password']))){
        $password_err = "Please enter a password.";
    } elseif(strlen(trim($_POST['password'])) < 6){
        $password_err = "Password must have at least 6 characters.";
    } else{
        $password = trim($_POST['password']);
    }

    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = 'Please confirm password.';
    } else{
        $confirm_password = trim($_POST['confirm_password']);
        if($password != $confirm_password){
            $confirm_password_err = 'Password did not match.';
        }
    }

    // Validate surname
    if(empty(trim($_POST['surname']))){
        $password_err = "Please enter a surname.";
//    } elseif(strlen(trim($_POST['password'])) < 2){
//        $password_err = "Surname must have atleast 2 characters.";
    } else{
        $surname = trim($_POST['surname']);
        $firstname = trim($_POST['firstname']);
        $sex = trim($_POST['sex']);
        $birthday = trim($_POST['birthday']);
        $admin = trim($_POST['admin']);
    }
    /////


    // Check input errors before inserting in database
    if(empty($login_err) && empty($password_err) && empty($confirm_password_err)){

        // Prepare an insert statement
        $sql = "INSERT INTO users (login, password, firstname, surname, sex, birthday, admin ) 
VALUES (:login, :password, :firstname, :surname, :sex, :birthday, :admin)";

        if($stmt = $pdo->prepare($sql)){
            // Set parameters
            $param_login = $login;
//            $param_password = $password;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            $param_firstname = $firstname;
            $param_surname = $surname;
            $param_sex = $sex;
            $param_birthday = $birthday;
            $param_admin = $admin;
            // Bind variables to the prepared statement as parameters
            $stmt->bindParam(':login', $param_login, PDO::PARAM_STR);
            $stmt->bindParam(':password', $param_password, PDO::PARAM_STR);
            $stmt->bindParam(':firstname', $param_firstname, PDO::PARAM_STR);
            $stmt->bindParam(':surname', $param_surname, PDO::PARAM_STR);
            $stmt->bindParam(':sex', $param_sex, PDO::PARAM_STR);
            $stmt->bindParam(':birthday', $param_birthday, PDO::PARAM_STR);
            $stmt->bindParam(':admin', $param_admin, PDO::PARAM_STR);


            // Attempt to execute the prepared statement
            if($stmt->execute()){
                // Redirect to login page
                header("location: /Site/index.php");
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }


        // Close statement
        unset($stmt);
    }

    // Close connection
    unset($pdo);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
    </style>
</head>
<body>
<div class="wrapper">
    <h2>Adding a new User</h2>
    <p>Please fill this form to create an account.</p>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <div class="form-group <?php echo (!empty($login_err)) ? 'has-error' : ''; ?>">
            <label>login</label>
            <input type="text" name="login" class="form-control" value="<?php echo $login; ?>">
            <span class="help-block"><?php echo $login_err; ?></span>
        </div>
        <div class="form-group <?php echo (!empty($password_err)) ? 'has-error' : ''; ?>">
            <label>Password</label>
            <input type="password" name="password" class="form-control" value="<?php echo $password; ?>">
            <span class="help-block"><?php echo $password_err; ?></span>
        </div>

        <div class="form-group <?php echo (!empty($firstname_err)) ? 'has-error' : ''; ?>">
            <label>first name</label>
            <input type="text" name="firstname" class="form-control" value="<?php echo $firstname; ?>">
            <span class="help-block"><?php echo $firstname_err; ?></span>
        </div>

        <div class="form-group <?php echo (!empty($surname_err)) ? 'has-error' : ''; ?>">
            <label>surname</label>
            <input type="text" name="surname" class="form-control" value="<?php echo $surname; ?>">
            <span class="help-block"><?php echo $surname_err; ?></span>
        </div>

        <div class="form-group <?php echo (!empty($sex_err)) ? 'has-error' : ''; ?>">
            <label>sex</label><br>
            <input type="radio" name="sex" value="1">Man
            <input type="radio" name="sex" value="0">Wooman<br>
            <span class="help-block"><?php echo $sex_err; ?></span>
        </div>

        <div class="form-group <?php echo (!empty($birthday_err)) ? 'has-error' : ''; ?>">
            <label>birthday</label>
            <input type="date" name="birthday" class="form-control" value="<?php echo $birthday; ?>">
            <span class="help-block"><?php echo $birthday_err; ?></span>
        </div>

        <div class="form-group <?php echo (!empty($admin_err)) ? 'has-error' : ''; ?>">
            <label>access rules</label><br>
            <input type="radio" name="admin" value="1">Admin
            <input type="radio" name="admin" value="0" checked>User
            <span class="help-block"><?php echo $admin_err; ?></span>
        </div>

        <div class="form-group <?php echo (!empty($confirm_password_err)) ? 'has-error' : ''; ?>">
            <label>Confirm Password</label>
            <input type="password" name="confirm_password" class="form-control" value="<?php echo $confirm_password; ?>">
            <span class="help-block"><?php echo $confirm_password_err; ?></span>
        </div>
        <div class="form-group">
            <input type="submit" class="btn btn-primary" value="Submit">
            <input type="reset" class="btn btn-default" value="Reset">
        </div>
        <a href="location: /Site/index.php">Index page</a>
    </form>
</div>
<a href="Libs/logout.php">Logout</a>

</body>
</html>