<?php


namespace Site\Libs;
use PDO;
//if(!defined("IN_ADMIN")) die;
class Storage
{
    private $dsn;
    private $charset='utf8';
    private $pdo;
    private $opt = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    public function __construct($host, $db, $user,$pass)
    {
        $this->dsn = "mysql:host=$host;dbname=$db;charset=$this->charset";
        $this->pdo = new PDO($this->dsn, $user, $pass, $this->opt);
    }

    public function getElementById($userId)
    {
        $stmt=$this->pdo->query("SELECT * FROM users WHERE id ={$userId};");
        $object=new User();
        $row = $stmt->fetch();
        $object->setFirstname($row['firstname']);
        $object->setId($row['id']);
        $object->setLogin($row['login']);
        $object->setFirstname($row['firstname']);
        $object->setSurname($row['surname']);
        $object->setSex($row['sex']);
        $object->setBirthday($row['birthday']);
        $object->setAdmin($row['admin']);
        return $object;
    }

    /**
     * @return array
     */
    public function readContacts(): array
    {
        $stmt=$this->pdo->query("SELECT * FROM users;");
        $array=[];
        while ($row = $stmt->fetch()){
            $object =new User();
            $object->setId($row['id']);
            $object->setLogin($row['login']);
            $object->setFirstname($row['firstname']);
            $object->setSurname($row['surname']);
            $object->setSex($row['sex']);
            $object->setBirthday($row['birthday']);
            $object->setAdmin($row['admin']);
            $array[] =$object;
        }
        return $array;
    }

    public function deleteContact($userId)
    {
        $stmt=$this->pdo->query("DELETE FROM users WHERE `id`={$userId};");
        $stmt->fetch();
        header("location: /Site/index.php");
    }
}