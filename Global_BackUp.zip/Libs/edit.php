<?php
//
//session_start();
//if(!isset($_SESSION['login']) || empty($_SESSION['login'])){
//    header("location: /Site/Libs/authorization.php");
//    exit;
//}
require_once 'config.php';

//$sql = "SELECT login, password, admin FROM users WHERE login = :login";
//$stmt = $pdo->prepare($sql);
//    $stmt->bindParam(':login', $param_login, PDO::PARAM_STR);
//    $param_login="root";
//    $row = $stmt->fetch();
//                var_dump($row['password']);


$sql = "SELECT * FROM users";
$stmt = $pdo->query($sql);
$row = $stmt->fetchAll();

    var_dump($row);

