<?php


namespace Site\Libs;

//if(!defined("IN_ADMIN")) die;
class User
{
    private $id;
    private $login;
    private $password;
    private $firstname;
    private $surname;
    private $sex;
    private $birthday;
    private $admin;

    public function toHtml()
    {
//        if(!empty($this->user)){
        $id=$this->getId();
        $login = $this->getLogin();
        $firstname = $this->getFirstname();
        $surname = $this->getSurname();
        $sex = $this->getSex();
        $birthday = $this->getBirthday();
        $admin = $this->getAdmin();
//        }
//        else{
//            $login    = "";
//            $password = "";
//            $name     = "";
//            $surname  = "";
//            $sex      = "";
//            $birthday = "";
//        }
        return "<tr>
                    <td>{$login}</td>
                    <td>{$firstname}</td>
                    <td>{$surname}</td>
                    <td>{$sex}</td>
                    <td>{$birthday}</td>
                    <td>{$admin}</td>
                    <td><input type='submit' value='View'>
                        <input type='submit' value='Delete'></td>
                    </tr>";

    }

//    public function toEdit() : string
//    {
//        $key = uniqid();
//        $login = $this->getLogin();
//        $password = $this->getPassword();
//        $firstname = $this->getFirstname();
//        $surname = $this->getSurname();
//        $sex = $this->getSex();
//        $birthday = $this->getBirthday();
////        }
////        else{
////            $login    = "";
////            $password = "";
////            $name     = "";
////            $surname  = "";
////            $sex      = "";
////            $birthday = "";
////        }
//        return "<div>
//                    <input type='text' name='user[{$key}][login]' value='{$login}' id='login_{$key}'/>
//                    <input type='text' name='user[{$key}][password]' value='{$password}' id='password_{$key}'>
//                    <input type='text' name='user[{$key}][firstname]' value='{$firstname}' id='firstname_{$key}'>
//                    <input type='text' name='user[{$key}][surname]' value='{$surname}' id='surname_{$key}'>
//                    <input type='text' name='user[{$key}][sex]' value='{$sex}' id='sex_{$key}'>
//                    <input type='text' name='user[{$key}][birthday]' value='{$birthday}' id='birthday_{$key}'>
//                </div>";
//
//    }

    /**
     * @return mixed
     */
    public function getLogin()
    {
        return $this->login;
    }

    /**
     * @param mixed $login
     */
    public function setLogin($login): void
    {
        $this->login = $login;
    }

    /**
     * @return mixed
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * @param mixed $password
     */
    public function setPassword($password): void
    {
        $this->password = $password;
    }


    /**
     * @return mixed
     */
    public function getSurname()
    {
        return $this->surname;
    }

    /**
     * @param mixed $surname
     */
    public function setSurname($surname): void
    {
        $this->surname = $surname;
    }

    /**
     * @return mixed
     */
    public function getSex()
    {
        return $this->sex;
    }

    /**
     * @param mixed $sex
     */
    public function setSex($sex): void
    {
        $this->sex = $sex;
    }

    /**
     * @return mixed
     */
    public function getBirthday()
    {
        return $this->birthday;
    }

    /**
     * @param mixed $birthday
     */
    public function setBirthday($birthday): void
    {
        $this->birthday = $birthday;
    }

    /**
     * @return mixed
     */
    public function getAdmin()
    {
        return $this->admin;
    }

    /**
     * @param mixed $admin
     */
    public function setAdmin($admin): void
    {
        $this->admin = $admin;
    }

    /**
     * @return mixed
     */
    public function getFirstname()
    {
        return $this->firstname;
    }

    /**
     * @param mixed $firstname
     */
    public function setFirstname($firstname): void
    {
        $this->firstname = $firstname;
    }

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     * @return User
     */
    public function setId($id)
    {
        $this->id = $id;
        return $this;
    }


}