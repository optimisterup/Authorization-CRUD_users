<?php
session_start();
if(!isset($_SESSION['login']) || empty($_SESSION['login'])){
    header("location: /Site/Libs/authorization.php");
    exit;
}
require_once 'Libs/config.php';

//config.php или Storage в storage поменять на дефолтные значения?????
//пагинация
//безопасность
//php doc
//документация

$sql = "SELECT * FROM users";
$stmt = $pdo->query($sql);
$download = $stmt->fetchAll();
require_once 'Libs/view/index.html';
?>

