<?php
session_destroy();
header("location: /Site/Libs/authorization.php");